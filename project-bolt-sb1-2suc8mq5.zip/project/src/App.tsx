import React, { useState } from 'react';
import { Search, MapPin, Clock, ShoppingBag, ChefHat, Star, Menu, X, Phone, Mail, MapPinIcon, Facebook, Instagram, Twitter, User, Lock, AtSign } from 'lucide-react';

const restaurants = [
  {
    id: 1,
    name: "Hilib Ari Express",
    rating: 4.8,
    deliveryTime: "25-35",
    image: "https://images.unsplash.com/photo-1535399831218-d5bd36d1a6b3?auto=format&fit=crop&q=80&w=800",
    tags: ["Hilib", "Bariis", "Baasto"]
  },
  {
    id: 2,
    name: "Muqmad & More",
    rating: 4.6,
    deliveryTime: "30-45",
    image: "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&q=80&w=800",
    tags: ["Muqmad", "Cambuulo", "Malawax"]
  },
  {
    id: 3,
    name: "Xalwo Corner",
    rating: 4.9,
    deliveryTime: "20-30",
    image: "https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&q=80&w=800",
    tags: ["Macmacaan", "Xalwo", "Buskud"]
  }
];

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: ''
  });

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Sign up data:', formData);
    setIsSignUpOpen(false);
    setFormData({
      name: '',
      email: '',
      password: '',
      phone: ''
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-md fixed w-full z-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <ChefHat className="h-8 w-8 text-orange-500 transform hover:rotate-12 transition-transform duration-300" />
              <span className="ml-2 text-2xl font-bold bg-gradient-to-r from-orange-500 to-red-600 text-transparent bg-clip-text hover:scale-105 transition-transform duration-300 cursor-pointer">DALBO</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="menu-item text-gray-700 hover:text-orange-500 transition-all font-medium">Bogga Hore</a>
              <a href="#" className="menu-item text-gray-700 hover:text-orange-500 transition-all font-medium">Nagu Saabsan</a>
              <a href="#" className="menu-item text-gray-700 hover:text-orange-500 transition-all font-medium">Nala Soo Xiriir</a>
              <button 
                onClick={() => setIsSignUpOpen(true)}
                className="order-button bg-orange-500 text-white px-6 py-2 rounded-full hover:bg-orange-600 transition-all shadow-lg hover:shadow-xl font-medium"
              >
                Dalbo Hadda
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-700 hover:text-orange-500 focus:outline-none transition-transform duration-300 hover:scale-110"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="mobile-menu md:hidden py-4 border-t">
              <a href="#" className="block py-2 text-gray-700 hover:text-orange-500 hover:bg-orange-50 px-4 rounded transition-all font-medium">Bogga Hore</a>
              <a href="#" className="block py-2 text-gray-700 hover:text-orange-500 hover:bg-orange-50 px-4 rounded transition-all font-medium">Nagu Saabsan</a>
              <a href="#" className="block py-2 text-gray-700 hover:text-orange-500 hover:bg-orange-50 px-4 rounded transition-all font-medium">Nala Soo Xiriir</a>
              <button 
                onClick={() => setIsSignUpOpen(true)}
                className="mt-2 w-full order-button bg-orange-500 text-white px-4 py-2 rounded-full hover:bg-orange-600 font-medium"
              >
                Dalbo Hadda
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Sign Up Modal */}
      {isSignUpOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6 transform transition-all signup-modal">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-gray-800">Is Diiwaangeli</h2>
              <button 
                onClick={() => setIsSignUpOpen(false)}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Magaca oo Buuxa
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="pl-10 w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all"
                    placeholder="Gali magacaaga oo buuxa"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Emailka
                </label>
                <div className="relative">
                  <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="pl-10 w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all"
                    placeholder="Gali emailkaaga"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Lambarka Mobilka
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="pl-10 w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all"
                    placeholder="Gali lambarka mobilkaaga"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Furaha Sirta ah
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className="pl-10 w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all"
                    placeholder="Gali furaha sirta ah"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-orange-500 text-white py-2 rounded-lg hover:bg-orange-600 transition-colors duration-300 transform hover:scale-[1.02] active:scale-[0.98] font-medium"
              >
                Is Diiwaangeli
              </button>
            </form>

            <p className="mt-4 text-sm text-gray-600 text-center">
              Hore ma u leedahay akoon? {' '}
              <a href="#" className="text-orange-500 hover:text-orange-600 font-medium">
                Halkan ka gal
              </a>
            </p>
          </div>
        </div>
      )}

      {/* Main Content with padding for fixed nav */}
      <div className="pt-16">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-orange-500 to-red-600 text-white">
          <div className="container mx-auto px-4 py-16 hero-content">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 hover:scale-105 transition-transform duration-300">DALBO</h1>
            <p className="text-xl mb-8 hover:translate-x-2 transition-transform duration-300">Dalbo cuntadaada macaan ee Soomaalida</p>
            
            <div className="relative max-w-2xl">
              <input
                type="text"
                placeholder="Raadi maqaayadaha..."
                className="w-full px-6 py-4 rounded-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-orange-300 transition-all duration-300 shadow-lg focus:shadow-xl"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-orange-500 transition-colors cursor-pointer" />
            </div>
          </div>
        </div>

        {/* Categories */}
        <div className="container mx-auto px-4 py-12">
          <h2 className="text-2xl font-bold mb-6 hover:text-orange-500 transition-colors duration-300">Noocyada Cuntada</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {['Quraac', 'Qado', 'Cashada', 'Macmacaan'].map((category) => (
              <div key={category} className="category-card bg-white rounded-lg p-6 shadow-md cursor-pointer">
                <ChefHat className="w-8 h-8 text-orange-500 mb-2 transform group-hover:rotate-12 transition-transform duration-300" />
                <h3 className="font-semibold">{category}</h3>
              </div>
            ))}
          </div>
        </div>

        {/* Restaurants */}
        <div className="container mx-auto px-4 py-12">
          <h2 className="text-2xl font-bold mb-6 hover:text-orange-500 transition-colors duration-300">Maqaayadaha</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {restaurants.map((restaurant) => (
              <div key={restaurant.id} className="restaurant-card bg-white rounded-lg overflow-hidden shadow-md">
                <div className="relative overflow-hidden">
                  <img 
                    src={restaurant.image} 
                    alt={restaurant.name} 
                    className="w-full h-48 object-cover transition-transform duration-300 hover:scale-110" 
                  />
                </div>
                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-lg hover:text-orange-500 transition-colors duration-300">{restaurant.name}</h3>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="ml-1">{restaurant.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center text-gray-600 text-sm mb-2">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{restaurant.deliveryTime} daqiiqo</span>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {restaurant.tags.map((tag) => (
                      <span key={tag} className="px-2 py-1 bg-gray-100 rounded-full text-sm hover:bg-orange-100 transition-colors">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Enhanced Footer */}
      <footer className="bg-gray-800 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <ChefHat className="h-8 w-8 text-orange-500 transform hover:rotate-12 transition-transform duration-300" />
                <h3 className="ml-2 text-2xl font-bold bg-gradient-to-r from-orange-500 to-red-600 text-transparent bg-clip-text hover:scale-105 transition-transform duration-300">DALBO</h3>
              </div>
              <p className="text-gray-400">Adeega gaarsiinta cuntada Soomaalida ee ugu tayada sarreeya</p>
            </div>
            
            <div>
              <h4 className="font-bold text-lg mb-4 hover:text-orange-500 transition-colors duration-300">Bogagga</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors menu-item">Bogga Hore</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors menu-item">Nagu Saabsan</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors menu-item">Maqaayadaha</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors menu-item">Noocyada Cuntada</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4 hover:text-orange-500 transition-colors duration-300">Nala Soo Xiriir</h4>
              <ul className="space-y-2">
                <li className="flex items-center text-gray-400 hover:text-white transition-colors">
                  <Phone className="w-5 h-5 mr-2" />
                  <span>+1 (555) 123-4567</span>
                </li>
                <li className="flex items-center text-gray-400 hover:text-white transition-colors">
                  <Mail className="w-5 h-5 mr-2" />
                  <span>info@dalbo.com</span>
                </li>
                <li className="flex items-center text-gray-400 hover:text-white transition-colors">
                  <MapPinIcon className="w-5 h-5 mr-2" />
                  <span>Mogadishu, Somalia</span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4 hover:text-orange-500 transition-colors duration-300">Nagu Soo Biir</h4>
              <p className="text-gray-400 mb-4">Ka mid noqo bulshadayada</p>
              <div className="flex space-x-4">
                <a href="#" className="social-icon text-gray-400 hover:text-white transition-colors">
                  <Facebook className="w-6 h-6" />
                </a>
                <a href="#" className="social-icon text-gray-400 hover:text-white transition-colors">
                  <Instagram className="w-6 h-6" />
                </a>
                <a href="#" className="social-icon text-gray-400 hover:text-white transition-colors">
                  <Twitter className="w-6 h-6" />
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2025 DALBO. Xuquuqda dhammaan waa dhowran tahay.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;